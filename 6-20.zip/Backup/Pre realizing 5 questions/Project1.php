<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>GGC Fashion Club</title>
	<link rel="stylesheet" href="normalize.css">
	<link rel="stylesheet" href="style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300italic,300' rel='stylesheet' type='text/css'>
	<script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
	<script src="main.js"></script>
	<script src="https://www.w3schools.com/lib/w3.js"></script>
    <title>Project1</title>
    </head>
    <body>
    
    <?php
        
        echo "<video autoplay muted loop id=\"myVideo\">";
        echo "<source src=\"main.mp4\" type=\"video/mp4\">";
        
        echo "</video>";
        echo "<div class = \"center-screen\">";
        echo "<h1>Thank you for completing the registration.</h1>";
       
        echo "<div class = \"wrp\">";
        echo "<p>";
        echo "Email: " . $_POST["email"] . "<br>";
        echo "Phone: " . $_POST["phone"] . "<br>";
        echo "Birthday: " . $_POST["luckyDay"] . "<br><br>";
        echo "Gender: " . $_POST["gender"] . "<br>";
        echo "level: " . $_POST["level"] . "<br><br>";
    
        echo "Your answers for the ITEC knowledge quiz:<br>";
        echo "Q1: ". $_POST["Q1"] . "<br>";
        echo "Q2: ". $_POST["Q2"] . "<br>";
        echo "Q3:";
        if ($_POST["Q3A"] == "yes")
            echo "A ";
        if ($_POST["Q3B"] == "yes")
            echo "B ";
        if ($_POST["Q3C"] == "yes")
            echo "C ";
        if ($_POST["Q3D"] == "yes")
            echo "D ";
        echo "<br>";
        echo "Q4: ". $_POST["Q4"] . "<br>";
        echo "<br>";

        $score = 0;
        if ($_POST["Q1"] == "D")
            $score += 50;
			$scoreQ1 = 50;
        if ($_POST["Q2"] == "A")
            $score += 50;
			$scoreQ2 = 50;
        if (($_POST["Q3A"] == "yes") && ($_POST["Q3B"] == "yes") && ($_POST["Q3C"] != "yes") && ($_POST["Q3D"] == "yes"))
            $score += 50;
			$scoreQ3 = 50;
         if ($_POST["Q4"] == "B")
            $score += 50;
			$scoreQ4 = 50;
        echo "Your quiz score: ";

        echo "<br><span style = 'color:red;'><b>" . $score . "</b></span></p>";
		echo "Rank: ";
		$rank = "Newcomer";
        if ($score == 50)
			$rank = "Beginner";
        else if ($score == 100)
			$rank = "Intermediate";
        else if ($score == 150)
			$rank = "Advanced";
        else if ($score == 200)
			$rank = "Expert";
        echo $rank;
        echo "<br>";
        echo "</div>";
        echo "</div>";
		
		date_default_timezone_get();
        $info = $_POST["firstName"]. "\t";
		$info = $_POST["lastName"]. "\t";
        $info = $_POST["luckyDay"]. "\t";
        $info = $_POST["gender"]. "\t";
        $info .= $_POST["email"]. "\t";
        $info .= $_POST["level"]. "\t";
        $info .= $scoreQ1 . "\t";
        $info .= $scoreQ2 . "\t";
        $info .= $scoreQ3 . "\t";
        $info .= $scoreQ4 . "\t";
        $info .= $score . "\t";
		$info .= $rank . "\t";
        $info .= date("m/d/Y") . "\t";
        $info .= date("h:i:sa") . "\t";
        $info .= $_SERVER["REMOTE_ADDR"] . "\n";
        
        $file = "TestScore.txt";
        file_put_contents($file ,$info, FILE_APPEND|LOCK_EX);
        echo "Click <a href = \"Project1Stat.php\">here</a> to view statistics";
    ?>
    </body>
</html>
