<!DOCTYPE html>
<html>
<head>
    <title>Project1</title>
    </head>
    <body>
    <?php
        $file = "TestScore.txt";
        $studentStr = file_get_contents($file);
        //echo $studentStr;
        $studentList = explode("\n",$studentStr);
        //print_r($studentList);
        array_pop($studentList);
        foreach($studentList as $index=>$student){
            $studentInfo[$index] = explode("\t", $student);
        }
        echo "<h2>Student List</h2>";
        echo "<table border = 1>";
        echo "<tr><th>First Name</th><th>Last Name</th><th>Birthday</th><th>Gender</th><th>Email</th><th>Level</th><th>Q1 Score</th><th>Q2 Score</th><th>Q3 Score</th><th>Q4 Score</th>
            <th>Total Score</th><th>Rank</th><th>Date</th><th>Time</th><th>IP Address</th></tr>";
        foreach ($studentInfo as $student){
            echo "<tr>";
                foreach($student as $item){
                    echo "<td>$item</td>";
                }
            echo "</tr>";
        }
        $q1avg = 0;
        $q1div = 0;
        $q2avg = 0;
        $q1div = 0;
        $q3avg = 0;
        $q3div = 0;
		$q4avg = 0;
        $q4div = 0;
        $sum = 0;
        echo "</table>";
        foreach($studentInfo as $student){
            foreach($student as $item){
                if($student[7] == 50){
                    $q1avg += 50;
                    }
                    $q1div += 50;
                 
                if($student[8] == 50){
                    $q2avg += 50;
                    }
                    $q2div += 50;
               if($student[9] == 50){
                    $q3avg += 50;
                    }
                    $q3div += 50; 
				if($student[10] == 50){
                    $q4avg += 50;
                    }
                    $q4div += 50;   
        }
        $sum += $student[11];
        }
        $nstudents = count($studentInfo);
        $sum = (round($sum /($nstudents * 150),2)*100);
        $q1avg = ($q1avg/$q1div) * 100;
        $q2avg = ($q2avg/$q2div) * 100;
        $q3avg = ($q3avg/$q3div) * 100;
        echo "Q1: $q1avg%<br>";
        echo "Q2: $q2avg%<br>";
        echo "Q3: $q3avg%<br>";
        echo "Average: $sum%<br>";

        $levelArray = array("freshmen"=>array("numStu"=>"0", "sumScore"=>"0"),
                            "sophomore"=>array("numStu"=>"0", "sumScore"=>"0"),
                            "junior"=>array("numStu"=>"0", "sumScore"=>"0"),
                            "senior"=>array("numStu"=>"0", "sumScore"=>"0"));
        foreach($studentInfo as $student){
            $levelArray[$student[2]]["numStu"] ++;
            $levelArray[$student[2]]["sumScore"] += $student[6];
        }
        echo "<table>";
        echo "<tr><th>Level</th><th>Number of Students</th><th>Percentage of students</th><th>Average Score</th></tr>";
        foreach($levelArray as $index=>$level) {
                echo "<tr>";
                echo "<td>$index</td>";
                echo "<td style = \"text-align:center;\">". $level["numStu"] . "</td>";
                echo "<td><meter value = \"".$level["numStu"]. "\"  max = \"$nstudents\"></meter>". 
                    (round($level["numStu"]/$nstudents,2)*100). "%</td>";
                echo "<td><progress value = \"".
                    round($level["sumScore"]/$level["numStu"]).
                    "\" max= \"150\"></progress>" . 
                    round($level["sumScore"]/$level["numStu"]). "</td>";
                echo "</tr>";
        }
        echo "</table>";
        
    ?>
    </body>
    </html>